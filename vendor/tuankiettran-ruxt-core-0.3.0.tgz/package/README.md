# Ruxt packages

A pnpm workspace with an explicit public/private domain boundary. These labels describe package ownership and distribution policy, not a new license grant or a change to GitHub/npm access controls.

## Packages and dependency direction

| Package | Location | Distribution | Owns |
|---|---|---|---|
| `@ruxt/shared` | `packages/shared` | Public | Generic value objects, datetime/email/phone, CQRS/saga, feature evaluator, analytics primitives, editor preferences, pure CV presentation/profile/document contracts and transformations |
| `@tuankiettran/ruxt-core` (aliased `@ruxt/core` in consumers) | repository root | Private, GitHub Packages (restricted) | Payment/billing, catalog/pricing, subscription lifecycle, IAM/password/auth policy, cloud consent, CV import/application implementations, all business handlers and repository ports |
| `@ruxt/editor` | `packages/editor` | Public Nuxt source layer | Route-free CodeMirror, Markdown preview, CSS isolation and pagination |

Dependency direction is **public shared <- private core**; the public editor may use public shared, never private core. Public source, declarations, package metadata and re-exports must not refer to private core. `pnpm lint` enforces the boundary with negative fixtures. Neither public package owns application HTTP routes, persistence adapters, authentication or deployment policy.

### Domain decisions

- Money/currency and billing-cycle rules remain with subscription/catalog, not public shared; payment objects retain full PAN in memory and must not enter public artifacts.
- Preferences expose only reusable editor schema/default normalization publicly; account handlers and repositories remain private.
- Analytics bucket/route/recorder primitives are reusable; collection/report/persistence handlers and ports remain private. No telemetry records are distributed.
- Pure CV schemas, value objects, Markdown split/compose/detection, optimistic revisions and local-backup reconciliation are judged reusable/non-proprietary. These are code/schema, not user CV content. CV import-job/application implementations and import wire/state schemas, quotas, consent, ownership, extraction orchestration and all handlers/ports remain private. Browser import controls use app-owned HTTP DTOs composed from shared presentation contracts, not private imports.
- Private auth handlers may use shared Email. Catalog and subscription stay together. Straddling CV handlers depend on shared presentation contracts plus private ports; no public compatibility barrel may re-export them.

## Layout and contracts

The root remains private core to avoid moving every private test/config file merely to add a nesting level. Canonical reusable implementation belongs in `packages/shared`; old root paths may contain thin inward-facing compatibility re-exports, not duplicate implementations. Private `handlers/` own one use case per file; `repos/` own interfaces implemented by applications. `ports/`, `services/` and top-level `analytics/` remain retired.

Core/shared expose finite documented export maps backed by generated ESM JavaScript and declarations, not sibling source aliases. The private Markdown tokenizer is not an exported subpath. Editor deliberately ships its Nuxt config, components/composable and complete internal utilities as source; private pagination must ship for relative imports but is not a public subpath. Do not reach into package `dist/` or unexported files from consumers.

## Local development and verification

```sh
pnpm install --frozen-lockfile
pnpm build
pnpm typecheck
pnpm test
pnpm exec vitest run --config packages/editor/vitest.config.ts
pnpm lint
```

The shared build precedes private core compilation so package imports/types resolve through actual export metadata. Build output is ignored. Local validation packs all three packages into the work area's `package-artifacts/phase4/`; Ruxt consumes those exact `file:` tarballs, including the same shared artifact for the private dependency. Regenerate packs before a fresh consumer install. No registry release is implied by this local workflow.

`NODE22_BINARY=/path/to/node22 node scripts/verify-package.js ../package-artifacts/phase4` verifies actual tar contents, finite exports, missing/private deep-path rejection, independent standard Node 22 runtime imports, strict NodeNext declarations and cross-package module identity. The Nuxt consumer build/typecheck separately validates the editor layer; plain Node cannot execute Vue SFCs. See the manager's acceptance record for actual runs, counts and remaining limits; command documentation is not test evidence.

## Release and privacy policy

This refactor does **not** push, publish, bump existing release versions, tag, deploy or merge. The new shared package starts at development version `0.0.0`; that is not a release. Existing core/editor versions are preserved.

- Root core has `private: true` as a publication safety guard and `publishConfig.access: restricted`. It is excluded from public publishing and public uploaded package artifacts. A future private-registry release needs separate authorization, registry/name/ACL review and deliberate removal of the local publication guard. Never pass `--access public` for core.
- Shared/editor have `publishConfig.access: public`, but are not published by a source push or this task. The Publish workflow is manually dispatched on `main` only, requires an explicit public-release confirmation input and the existing protected `npm-publish` environment, and only considers the two public package directories. Development version `0.0.0` is skipped.
- A separately authorized future public release must build/test/typecheck/lint, inspect packs and consumer checks, review licenses and private-boundary proof, then use npm Trusted Publishing/OIDC with provenance. No long-lived token belongs in source or commands. Registry setup/2FA/environment reviewers remain owner-admin responsibilities.
- Local metadata does not revoke historical public versions, remove public Git history, change repository visibility, or establish registry ACLs. Those remote operations were not performed or authorized. Do not claim source secrecy from package metadata alone.

No open-source license has been granted. Public package designation and repository readability do not grant reuse rights; those remain with the repository owner until a license is explicitly authorized.

## Private core on GitHub Packages

`@tuankiettran/ruxt-core` is published to `https://npm.pkg.github.com` with restricted access (the scope must equal the GitHub owner). It never goes to the public npm registry; lint requires `publishConfig.registry` to be GitHub Packages. Release it with the manual `publish-core.yml` workflow from `main` (uses `GITHUB_TOKEN`, `packages: write`). Consumers add `@tuankiettran:registry=https://npm.pkg.github.com` to `.npmrc`, authenticate with a token that has `read:packages`, and alias it: `"@ruxt/core": "npm:@tuankiettran/ruxt-core@<version>"`. Grant the consuming repository read access to the package in the package settings so its `GITHUB_TOKEN` can install it.
