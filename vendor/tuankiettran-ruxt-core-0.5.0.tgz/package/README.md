# Ruxt packages

Framework-free domain packages and a reusable Nuxt editor layer.

| Package | Location | Distribution |
| --- | --- | --- |
| @tuankiettran/ruxt-core 0.5.0 | Repository root | Restricted GitHub Packages; consumed as @ruxt/core |
| @ruxt/shared 0.1.0 | packages/shared | Public npm |
| @ruxt/editor 0.1.2 | packages/editor | Public npm source layer |

See [specifications](specs/README.md) for ownership, exports, domain contracts, and release workflows.

## Development

Use a current Node 22 LTS patch and pnpm 11.25.0.

~~~sh
pnpm install --frozen-lockfile
pnpm build
pnpm typecheck
pnpm test
pnpm exec vitest run --config packages/editor/vitest.config.ts
pnpm lint
~~~

Shared builds before private core. Applications consume versioned package artifacts; sibling source changes do not update consumers automatically.

Public distribution does not grant a license. No open-source license is currently supplied.
